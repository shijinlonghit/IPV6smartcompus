package com.example.samrtcampus.ipv6smartcampus2;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.ClassTable;
import com.example.samrtcampus.ipv6smartcampus2.adapter.ClassTableAdapter;
import com.example.samrtcampus.ipv6smartcampus2.entity.ClassInformation;
import com.example.samrtcampus.ipv6smartcampus2.ui.ClassroomInformationActivity;
import com.example.samrtcampus.ipv6smartcampus2.view.ExpandTabView;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewLeft;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewMiddle;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewRight;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class ClassroomActivity extends AppCompatActivity implements View.OnClickListener{

    public static final int BMOB_CLASSDATA = 102;
    //查询相关
    private ListView listData;
    private List<ClassInformation> list1 = new ArrayList<ClassInformation>();
    //最终教室
    private String chooseClass;
    //定义控件
    private Button classroomCommit;
    private EditText et_classroomDate;
    //定义载体传值
    private HashMap<String,String > mHashMap;
    private List<Map<String,String>> mapList;
    //最终日期
    private String chooseDate;
    //教室名称
    private String ClassName;
    private String ClassName1;
    private String ClassName2;
    private String ClassName3;
    private String ClassName4;
    private String ClassName5;
    private ClassTableAdapter adapter;


    private ExpandTabView expandTabView;
    private ArrayList<View> mViewArray = new ArrayList<View>();
    private ViewLeft viewLeft;
    private ViewMiddle viewMiddle;
    private ViewRight viewRight;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case BMOB_CLASSDATA:
                    adapter = new ClassTableAdapter(ClassroomActivity.this,list1);
                    listData.setAdapter(adapter);
                    listData.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            switch (position){
                                case 0:
                                    if (TextUtils.equals(ClassName,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {

                                    }
                                    Intent intent = new Intent(ClassroomActivity.this, ClassroomInformationActivity.class);
                                    intent.putExtra("Classdata",ClassName);
                                    intent.putExtra("Class",chooseClass);
                                    intent.putExtra("Date",chooseDate);
                                    startActivity(intent);
                                    break;
                                case 1:
                                    if (TextUtils.equals(ClassName1,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent1 = new Intent(ClassroomActivity.this,ClassroomInformationActivity.class);
                                        intent1.putExtra("Classdata",ClassName1);
                                        intent1.putExtra("Class",chooseClass);
                                        intent1.putExtra("Date",chooseDate);
                                        startActivity(intent1);
                                    }

                                    break;
                                case 2:
                                    if (TextUtils.equals(ClassName2,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent2 = new Intent(ClassroomActivity.this,ClassroomInformationActivity.class);
                                        intent2.putExtra("Classdata",ClassName2);
                                        intent2.putExtra("Class",chooseClass);
                                        intent2.putExtra("Date",chooseDate);
                                        startActivity(intent2);
                                    }

                                    break;
                                case 3:
                                    if (TextUtils.equals(ClassName3,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent3 = new Intent(ClassroomActivity.this,ClassroomInformationActivity.class);
                                        intent3.putExtra("Classdata",ClassName3);
                                        intent3.putExtra("Class",chooseClass);
                                        intent3.putExtra("Date",chooseDate);
                                        startActivity(intent3);
                                    }

                                    break;
                                case 4:
                                    if (TextUtils.equals(ClassName4,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent4 = new Intent(ClassroomActivity.this,ClassroomInformationActivity.class);
                                        intent4.putExtra("Classdata",ClassName4);
                                        intent4.putExtra("Class",chooseClass);
                                        intent4.putExtra("Date",chooseDate);
                                        startActivity(intent4);
                                    }

                                    break;
                                case 5:
                                    if (TextUtils.equals(ClassName5,"无")){
                                        Toast.makeText(ClassroomActivity.this,"该节课没有安排",Toast.LENGTH_SHORT).show();
                                    }else {
                                        Intent intent5 = new Intent(ClassroomActivity.this,ClassroomInformationActivity.class);
                                        intent5.putExtra("Classdata",ClassName5);
                                        intent5.putExtra("Class",chooseClass);
                                        intent5.putExtra("Date",chooseDate);
                                        startActivity(intent5);
                                    }

                                    break;
                            }

                        }
                    });
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classroom);
        initView();
        initVaule();
        initListener();


    }


    private void initView() {

        expandTabView = (ExpandTabView) findViewById(R.id.expandtab_view);
        viewLeft = new ViewLeft(this);
        viewMiddle = new ViewMiddle(this);
        viewRight = new ViewRight(this);
        //声明listview
        listData = findViewById(R.id.list);
        classroomCommit =findViewById(R.id.classroom_commit);
        classroomCommit.setOnClickListener(this);
        et_classroomDate = findViewById(R.id.classroom_date);

    }

    private void initVaule() {

		mViewArray.add(viewLeft);
//		mViewArray.add(viewMiddle);
//		mViewArray.add(viewRight);
        ArrayList<String> mTextArray = new ArrayList<String>();
		mTextArray.add("请选择教室");
//        mTextArray.add("校园建筑");
//		mTextArray.add("项目2");
        expandTabView.setValue(mTextArray, mViewArray);
//		expandTabView.setTitle(viewLeft.getShowText(), 0);
//		expandTabView.setTitle(viewMiddle.getShowText(), 1);
//		expandTabView.setTitle(viewRight.getShowText(), 2);


        list1.add(new ClassInformation("8:00——9:45","第1、2节",""));
        list1.add(new ClassInformation("10:00——11:45","第3、4节",""));
        list1.add(new ClassInformation("13:30——15:15","第5、6节",""));
        list1.add(new ClassInformation("15:30——17:15","第7、8节",""));
        list1.add(new ClassInformation("18:00——19:45","第9、10节",""));
        list1.add(new ClassInformation("20:00——21:45","第11、12节",""));
        adapter = new ClassTableAdapter(this,list1);
        listData.setAdapter(adapter);


    }

    private void initListener() {

        viewLeft.setOnSelectListener(new ViewLeft.OnSelectListener() {

            @Override
            public void getValue(String showText) {
                onRefresh(viewLeft, showText);
            }
        });

        viewMiddle.setOnSelectListener(new ViewMiddle.OnSelectListener() {

            @Override
            public void getValue(String showText) {

                onRefresh(viewMiddle,showText);

            }
        });

        viewRight.setOnSelectListener(new ViewRight.OnSelectListener() {

            @Override
            public void getValue(String distance, String showText) {
                onRefresh(viewRight, showText);
            }
        });

    }

    //添加点击事件
    private void onRefresh(View view, String showText) {

        expandTabView.onPressBack();
        int position = getPositon(view);
        if (position >= 0 && !expandTabView.getTitle(position).equals(showText)) {
            expandTabView.setTitle(showText, position);
        }
        chooseClass=showText;
        //Toast.makeText(MainActivity.this, showText, Toast.LENGTH_SHORT).show();

    }

    private int getPositon(View tView) {
        for (int i = 0; i < mViewArray.size(); i++) {
            if (mViewArray.get(i) == tView) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onBackPressed() {

        if (!expandTabView.onPressBack()) {
            finish();
        }

    }

    public void Query(String date,String string){
        //创建list用于存放mHashmap
        mapList = new ArrayList<>();

        //查询
        BmobQuery<ClassTable> query = new BmobQuery<ClassTable>();
        List<BmobQuery<ClassTable>> and = new ArrayList<BmobQuery<ClassTable>>();
        //日期
        BmobQuery<ClassTable> q1 = new BmobQuery<ClassTable>();

        q1.addWhereEqualTo("Date",date);
        and.add(q1);
        //教室
        BmobQuery<ClassTable> q2 = new BmobQuery<ClassTable>();
        q2.addWhereEqualTo("ClassPosition",string);
        and.add(q2);
        //组合条件
        query.and(and);
        query.findObjects(new FindListener<ClassTable>() {
            @Override
            public void done(List<ClassTable> list, BmobException e) {
                if (e==null){
                    for (final ClassTable classTable : list){
                        //初始化HashMap
                        mHashMap = new HashMap<>();
                        mHashMap.put("ClassNmame",classTable.getClassName());//第一节
                        mHashMap.put("ClassNmame1",classTable.getClassName1());//第二节
                        mHashMap.put("ClassNmame2",classTable.getClassName2());//第三节
                        mHashMap.put("ClassNmame3",classTable.getClassName3());//第四节
                        mHashMap.put("ClassNmame4",classTable.getClassName4());//第五节
                        mHashMap.put("ClassNmame5",classTable.getClassName5());//第六节
                        mapList.add(mHashMap);

                    }


                }else {
                    Toast.makeText(ClassroomActivity.this,"无当天课表，请重新选择",Toast.LENGTH_SHORT).show();
                    Log.i("Bmob","失败:"+e.getMessage()+","+e.getErrorCode());
                }


                list1.clear();
                list1.add(new ClassInformation("8:00——9:45","第1、2节",mapList.get(0).get("ClassNmame")));
                list1.add(new ClassInformation("10:00——11:45","第3、4节",mapList.get(0).get("ClassNmame1")));
                list1.add(new ClassInformation("13:30——15:15","第5、6节",mapList.get(0).get("ClassNmame2")));
                list1.add(new ClassInformation("15:30——17:15","第7、8节",mapList.get(0).get("ClassNmame3")));
                list1.add(new ClassInformation("18:00——19:45","第9、10节",mapList.get(0).get("ClassNmame4")));
                list1.add(new ClassInformation("20:00——21:45","第11、12节",mapList.get(0).get("ClassNmame5")));

                ClassName = mapList.get(0).get("ClassNmame");
                ClassName1 = mapList.get(0).get("ClassNmame1");
                ClassName2 = mapList.get(0).get("ClassNmame2");
                ClassName3 = mapList.get(0).get("ClassNmame3");
                ClassName4 = mapList.get(0).get("ClassNmame4");
                ClassName5 = mapList.get(0).get("ClassNmame5");


                Toast.makeText(ClassroomActivity.this,"查询成功",Toast.LENGTH_LONG).show();

                Message msg =Message.obtain();
                msg.what= BMOB_CLASSDATA;
                mHandler.sendMessage(msg);

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.classroom_commit:

                chooseDate=et_classroomDate.getText().toString().trim();
                if (!TextUtils.isEmpty(chooseDate)&!TextUtils.isEmpty(chooseClass)){
                    Query(chooseDate,chooseClass);
                }else {
                    Toast.makeText(ClassroomActivity.this,"请选择教室和日期",Toast.LENGTH_SHORT).show();
                }
                break;
        }

    }
}
