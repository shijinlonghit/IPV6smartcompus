package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.samrtcampus.ipv6smartcampus2.MapActivity;
import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.Search.ICallBack;
import com.example.samrtcampus.ipv6smartcampus2.Search.SearchView;
import com.example.samrtcampus.ipv6smartcampus2.Search.bCallBack;

/**
 * Created by yangz on 2018/5/21.
 */

public class MapSearchActivity extends AppCompatActivity{
    // 1. 初始化搜索框变量
    private SearchView searchView;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_search);
        searchView = (SearchView) findViewById(R.id.search_view1);
        // 3. 绑定组件
        searchView = (SearchView) findViewById(R.id.search_view);

        // 4. 设置点击搜索按键后的操作
        // 参数=搜索框输入的内容
        searchView.setOnClickSearch(new ICallBack() {
            @Override
            public void SearchAciton(String string) {

                    Intent intent = new Intent(MapSearchActivity.this,MapActivity.class);
                    intent.putExtra("data",string);
                    finish();
                //System.out.println("我收到了" + string);
            }
        });

        // 5. 设置点击返回按钮后的操作
        searchView.setOnClickBack(new bCallBack() {
            @Override
            public void BackAciton() {
                finish();
            }
        });
    }

}
