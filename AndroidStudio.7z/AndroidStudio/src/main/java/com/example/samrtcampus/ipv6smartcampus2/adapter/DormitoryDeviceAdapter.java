package com.example.samrtcampus.ipv6smartcampus2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.RequiredDevice;
import com.example.samrtcampus.ipv6smartcampus2.R;

import java.util.List;

/**
 * Created by yangz on 2018/5/21.
 */

public class DormitoryDeviceAdapter extends BaseAdapter{
    private Context mContext;
    private LayoutInflater inflater;
    private List<RequiredDevice> mList;
    private RequiredDevice requiredDevice;

    public DormitoryDeviceAdapter(Context mContext, List<RequiredDevice>mList){
        this.mContext = mContext;
        this.mList = mList;
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder =null;
        if (convertView == null){
            viewHolder  = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_lv_dormitory_device,null);
            viewHolder.required_device=convertView.findViewById(R.id.required_device);
            viewHolder.commit_time=convertView.findViewById(R.id.commit_time);
            viewHolder.device_status=convertView.findViewById(R.id.device_status);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        requiredDevice=mList.get(position);
        viewHolder.required_device.setText(requiredDevice.getDeviceName());
        viewHolder.commit_time.setText(requiredDevice.getCreatedAt());
        viewHolder.device_status.setText(requiredDevice.getStatus());


        return convertView;
    }

    class ViewHolder{
        private TextView required_device;
        private TextView commit_time;
        private TextView device_status;


    }
}
