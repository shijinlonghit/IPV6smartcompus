package com.example.samrtcampus.ipv6smartcampus2.entity;

/**
 * Created by yangz on 2018/5/19.
 */

public class XueShiBuildDeviceData {
    private XueShiBuildDeviceData deviceNumber;

    public XueShiBuildDeviceData getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(XueShiBuildDeviceData deviceNumber) {
        this.deviceNumber = deviceNumber;
    }
}
