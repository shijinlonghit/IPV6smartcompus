package com.example.samrtcampus.ipv6smartcampus2.entity;

import cn.bmob.v3.BmobUser;

/**
 * 用户属性
 * Created by yangz on 2018/4/19.
 */

public class MyUser extends BmobUser {
    private boolean sex;
    private String desc;
    private String identity;

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
