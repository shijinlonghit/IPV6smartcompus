package com.example.samrtcampus.ipv6smartcampus2.DataClass;

import cn.bmob.v3.BmobObject;

/**
 * Created by yangz on 2018/5/20.
 */

public class ClassInfo extends BmobObject {
    private String ClassName;
    private String Date;
    private String Teacher;
    private String ClassPosition;
    private String ClassContent;

    public String getClassName() {
        return ClassName;
    }

    public void setClassName(String className) {
        ClassName = className;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTeacher() {
        return Teacher;
    }

    public void setTeacher(String teacher) {
        Teacher = teacher;
    }

    public String getClassPosition() {
        return ClassPosition;
    }

    public void setClassPosition(String classPosition) {
        ClassPosition = classPosition;
    }

    public String getClassContent() {
        return ClassContent;
    }

    public void setClassContent(String classContent) {
        ClassContent = classContent;
    }
}
