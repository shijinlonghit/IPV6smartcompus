package com.example.samrtcampus.ipv6smartcampus2.Search;

/**
 * Created by yangz on 2018/5/20.
 */

public interface bCallBack {
    void BackAciton();
}
