package com.example.samrtcampus.ipv6smartcampus2.DataClass;

import cn.bmob.v3.BmobObject;

/**
 * Created by yangz on 2018/5/21.
 */

public class RequiredDevice extends BmobObject{
    private String DeviceName;
    private String DeviceInfo;
    private String Status;

    public String getDeviceName() {
        return DeviceName;
    }

    public void setDeviceName(String deviceName) {
        DeviceName = deviceName;
    }

    public String getDeviceInfo() {
        return DeviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        DeviceInfo = deviceInfo;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
