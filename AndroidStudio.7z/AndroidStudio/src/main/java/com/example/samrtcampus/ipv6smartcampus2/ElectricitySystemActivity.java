package com.example.samrtcampus.ipv6smartcampus2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.example.samrtcampus.ipv6smartcampus2.entity.MarkerInfoElec;

import java.util.List;

import static com.example.samrtcampus.ipv6smartcampus2.entity.MarkerInfoElec.infose;

public class ElectricitySystemActivity extends AppCompatActivity implements View.OnClickListener{

    //地图相关
    private MapView mMapView;
    private BaiduMap mBaiduMap;
    //控件

    //覆盖物相关
    private RelativeLayout mMarkerLy;
    private BitmapDescriptor mMarkerElec;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        //注意该方法要再setContentView方法之前实现
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_electricity_system);

        initView();

        initMarker();

        addOverlays(infose);

        mBaiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {


                Bundle extraInfo = marker.getExtraInfo();
                MarkerInfoElec markerInfoElec = (MarkerInfoElec) extraInfo.getSerializable("markerInfoElec");
                ImageView iv = mMarkerLy.findViewById(R.id.electricity_device_img);
                TextView deviceNumber = mMarkerLy.findViewById(R.id.electricity_device_id);
                TextView deviceType = mMarkerLy.findViewById(R.id.electricity_device_type);

                iv.setImageResource(markerInfoElec.getImgId());
                deviceNumber.setText(markerInfoElec.getDeviceNumber()+"");
                deviceType.setText(markerInfoElec.getDeviceType());


                mMarkerLy.setVisibility(View.VISIBLE);
                return true;
            }
        });

        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                mMarkerLy.setVisibility(View.GONE);
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {


                return false;
            }
        });
    }



    private void initView() {
        //初始化控件

        //初始化布局
        mMarkerLy = findViewById(R.id.electricity_markerInfo);

        //获取地图控件引用
        mMapView = findViewById(R.id.bmapView1);
        mBaiduMap = mMapView.getMap();
        //设置地图放大级别
        MapStatusUpdate mapUpdate = MapStatusUpdateFactory.zoomTo(15.0f);
        //更改地图状态
        mBaiduMap.setMapStatus(mapUpdate);

    }

    private void initMarker() {
        mMarkerElec = BitmapDescriptorFactory.fromResource(R.mipmap.icon_location_elec);
    }

    private void addOverlays(List<MarkerInfoElec> infose){
        mBaiduMap.clear();//清除一些图层
        LatLng latLng =null;
        Marker marker =null;
        OverlayOptions options;
        for (MarkerInfoElec markerInfo:infose){
            //经纬度
            latLng = new LatLng(markerInfo.getLatitude(),markerInfo.getLongitude());
            //图标
            options = new MarkerOptions().position(latLng).icon(mMarkerElec).zIndex(5);
            marker =(Marker) mBaiduMap.addOverlay(options);
            Bundle arg0 = new Bundle();
            arg0.putSerializable("markerInfoElec",markerInfo);
            marker.setExtraInfo(arg0);
        }

        MapStatusUpdate msu =MapStatusUpdateFactory.newLatLng(latLng);
        mBaiduMap.setMapStatus(msu);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mMapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mMapView.onDestroy();
    }
}
