package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.entity.MyUser;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class RegisteredActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText et_account;
    private EditText et_identity;
    private EditText et_desc;
    private RadioGroup mRadioGroup;
    private EditText et_password;
    private EditText et_pass;
    private EditText et_email;
    private Button btnRegistered;
    //性别
    private boolean isGender=true;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered);

        initView();
    }

    private void initView() {
        et_account = findViewById(R.id.et_account);
        et_identity = findViewById(R.id.et_identity);
        et_desc = findViewById(R.id.et_desc);
        mRadioGroup = findViewById(R.id.mRadioGroup);
        et_pass = findViewById(R.id.et_pass);
        //内容监听器
//        et_pass.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                if (editable.length()<6){
//                    Toast.makeText(RegisteredActivity.this,"输入的密码应大于6位",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
        et_password = findViewById(R.id.et_password);
        et_email = findViewById(R.id.et_email);
        btnRegistered = findViewById(R.id.btn_registered_commit);
        btnRegistered.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_registered_commit:
                //获取到输入框的值
                String account=et_account.getText().toString().trim();
                String identity=et_identity.getText().toString().trim();
                String desc=et_desc.getText().toString().trim();
                String pass=et_pass.getText().toString().trim();
                String password=et_password.getText().toString().trim();
                String email=et_email.getText().toString().trim();

                //判断是否为空
                if (!TextUtils.isEmpty(account)&!TextUtils.isEmpty(identity)&
                        !TextUtils.isEmpty(pass)&!TextUtils.isEmpty(password)&
                        !TextUtils.isEmpty(email)){
                    //判断两次输入的密码是否一致
                    if (pass.equals(password)) {
                        //先把性别判断一下
                        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                                if (i == R.id.rb_boy) {
                                    isGender = true;
                                } else if (i == R.id.rb_girl) {
                                    isGender = false;
                                }
                            }
                        });
                        //判断账号形式是否正确（没有实现）
                        //判断身份输入是否正确
                        if (!identity.equals(this.getString(R.string.student))&
                                !identity.equals(this.getString(R.string.teacher))&
                                !identity.equals(this.getString(R.string.manager)) ){
                            Toast.makeText(this,"您输入的身份不正确",Toast.LENGTH_SHORT).show();
                        }else {

                            //注册
                            MyUser user = new MyUser();
                            user.setUsername(account);
                            user.setPassword(password);
                            user.setEmail(email);
                            user.setSex(isGender);
                            user.setIdentity(identity);

                            user.signUp(new SaveListener<Object>() {
                                @Override
                                public void done(Object o, BmobException e) {
                                    if (e==null){
                                        Toast.makeText(RegisteredActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
                                        finish();
                                    }else {
                                        Toast.makeText(RegisteredActivity.this,"注册失败",Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }

                        }else {
                        Toast.makeText(this,"两次输入的密码不一致",Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText(this,"输入框不能为空",Toast.LENGTH_SHORT).show();
                }

                break;
        }
    }
}
