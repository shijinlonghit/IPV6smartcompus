package com.example.samrtcampus.ipv6smartcampus2;
/**
 * 记住密码的功能没有实现
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.entity.MyUser;
import com.example.samrtcampus.ipv6smartcampus2.ui.ForgetPasswordActivity;
import com.example.samrtcampus.ipv6smartcampus2.ui.RegisteredActivity;
import com.example.samrtcampus.ipv6smartcampus2.utils.ShareUtils;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btn_login;
    private Button btn_registered;
    private EditText et_account;
    private EditText et_password;
    private CheckBox keep_password;
    private LinearLayout ly_forgetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();
    }

    private void initView() {
        btn_login=findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
        btn_registered=findViewById(R.id.btn_registered);
        btn_registered.setOnClickListener(this);
        et_account=findViewById(R.id.et_account);
        et_password=findViewById(R.id.et_password);
        keep_password=findViewById(R.id.keep_password);
        ly_forgetPassword = findViewById(R.id.layout_forgetPassword);
        ly_forgetPassword.setOnClickListener(this);

        //设置选中的状态
        boolean isCheck=ShareUtils.getBoolean(this,"keepword",false);
        keep_password.setChecked(isCheck);
        if (isCheck){
            //设置密码
            String account =ShareUtils.getString(this,"account","");
            String password =ShareUtils.getString(this,"password","");
            et_account.setText(account);
            et_password.setText(password);
            //et_account.setText(ShareUtils.getString(this,"account",""));
            //et_password.setText(ShareUtils.getString(this,"password",""));
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_login:
                //1.获取输入框的值
                String account=et_account.getText().toString().trim();
                String password=et_password.getText().toString();
                //2.判断是否为空
                if (!TextUtils.isEmpty(account)&!TextUtils.isEmpty(password)){
                    //登录
                    final MyUser user=new MyUser();
                    user.setUsername(account);
                    user.setPassword(password);

                    {
                        startActivity(new Intent(LoginActivity.this,MainActivity.class));

                        finish();
                    }

                    /*
                    user.login(new SaveListener<MyUser>() {
                        @Override
                        public void done(MyUser myUser, BmobException e) {
                            //判断结果
                            if (e==null){
                                //判断邮箱是否验证
                                if (user.getEmailVerified()){
                                    //跳转
                                    startActivity(new Intent(LoginActivity.this,MainActivity.class));

                                    finish();
                                }else{
                                    Toast.makeText(LoginActivity.this,"请前往邮箱验证账号",Toast.LENGTH_SHORT).show();
                                }
                            }else {
                                Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    */
                }else {
                    Toast.makeText(this,"输入框不能为空",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_registered:
                startActivity(new Intent(LoginActivity.this, RegisteredActivity.class));
                break;
            case R.id.layout_forgetPassword:
                startActivity(new Intent(LoginActivity.this, ForgetPasswordActivity.class));
                break;
        }
    }

    //假设我现在输入用户名和密码，但是我不点击登录，而是直接退出了
    @Override
    protected void onDestroy() {
        super.onDestroy();

        //保存状态
        ShareUtils.putBoolean(this,"keepword",keep_password.isChecked());
        //是否记住密码
        if (keep_password.isChecked()){
            //记住用户名和密码
            ShareUtils.putString(this,"account",et_account.getText().toString().trim());
            ShareUtils.putString(this,"password",et_password.getText().toString().trim());
        }else {
            ShareUtils.deleShare(this,"account");
            ShareUtils.deleShare(this,"password");
        }
    }
}
