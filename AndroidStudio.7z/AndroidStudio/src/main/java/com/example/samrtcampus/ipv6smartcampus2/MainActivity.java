package com.example.samrtcampus.ipv6smartcampus2;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.samrtcampus.ipv6smartcampus2.ui.SearchActivity;


public class MainActivity extends AppCompatActivity {

    //private ImageView iv_search;
    //private RelativeLayout search;
    private EditText tv_search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {
        /*
        search = findViewById(R.id.layout_search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });*/
        tv_search =findViewById(R.id.tv_search);
        tv_search.setFocusable(false);
        tv_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
        /*
        iv_search=findViewById(R.id.iv_search);
        iv_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"按钮被点击",Toast.LENGTH_SHORT).show();
            }
        });*/
    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.layout_fire:
                startActivity(new Intent(MainActivity.this,EnergyMapActivity.class));
                //Toast.makeText(this,"布局被点击",Toast.LENGTH_SHORT).show();
                break;
            case R.id.layout_electricity:
                startActivity(new Intent(MainActivity.this,ElectricitySystemActivity.class));
                break;
            case R.id.layout_water:
                startActivity(new Intent(MainActivity.this,WaterSystemActivity.class));
            case R.id.layout_camera:
                startActivity(new Intent(MainActivity.this,VideoActivity.class));
                break;
            case R.id.layout_light:
                startActivity(new Intent(MainActivity.this,LightActivity.class));
                break;
            case R.id.layout_dormitory:
                startActivity(new Intent(MainActivity.this,DormitoryActivity.class));
                break;
            case R.id.layout_classroom:
                startActivity(new Intent(MainActivity.this,ClassroomActivity.class));
                break;
            case R.id.layout_map:
                startActivity(new Intent(MainActivity.this,MapActivity.class));
                break;
            case R.id.layout_main_setting:
                startActivity(new Intent(MainActivity.this,SettingActivity.class));
                break;
            case R.id.layout_about_us:
                startActivity(new Intent(MainActivity.this,AboutUsActivity.class));
                break;
        }
    }
}

