package com.example.samrtcampus.ipv6smartcampus2.application;

import android.app.Application;

import com.example.samrtcampus.ipv6smartcampus2.utils.StaticClass;
import com.tencent.bugly.crashreport.CrashReport;

import cn.bmob.v3.Bmob;

/**
 * 启动App的时候先启动Application，生命周期与整个App相同
 *
 * Created by yangz on 2018/4/17.
 */

public class BaseApplication extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
        //初始化Bugly
        CrashReport.initCrashReport(getApplicationContext(), StaticClass.BUGLY_APP_ID, true);
        //初始化Bmob
        Bmob.initialize(this, StaticClass.BMOB_APP_ID);

    }


}
