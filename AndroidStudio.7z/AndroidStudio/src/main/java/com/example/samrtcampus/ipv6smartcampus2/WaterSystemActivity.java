package com.example.samrtcampus.ipv6smartcampus2;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.MapView;
import com.example.samrtcampus.ipv6smartcampus2.utils.MyOrientationListener;

public class WaterSystemActivity extends AppCompatActivity implements View.OnClickListener{
    /**
     * 定位功能
     * 1.LocationCli
     */
    private Context context;

    //控件
    private Button btn_myLocation;
    //地图相关
    private MapView mMapView;
    private BaiduMap mBaiduMap;

    //定位相关
    public LocationClient mLocationClient = null;
    private boolean isFirstIn =true;
    private double mLatitude;
    private double mLongitude;
    //自定义定位图标
    private BitmapDescriptor mIconLocation;
    private MyOrientationListener myOrientationListener;
    private float mCurrentX;

    //覆盖物相关
    //覆盖物
    private BitmapDescriptor mMarker;
    //覆盖物信息布局
    private RelativeLayout mMarkerLy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        //注意该方法要再setContentView方法之前实现
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_water_system);

        this.context = this;
        }

    @Override
    public void onClick(View v) {

    }
}
