package com.example.samrtcampus.ipv6smartcampus2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.poi.OnGetPoiSearchResultListener;
import com.baidu.mapapi.search.poi.PoiDetailResult;
import com.baidu.mapapi.search.poi.PoiIndoorResult;
import com.baidu.mapapi.search.poi.PoiResult;
import com.baidu.mapapi.search.poi.PoiSearch;
import com.example.samrtcampus.ipv6smartcampus2.entity.Building;
import com.example.samrtcampus.ipv6smartcampus2.ui.MapSearchActivity;
import com.example.samrtcampus.ipv6smartcampus2.utils.L;
import com.example.samrtcampus.ipv6smartcampus2.utils.MyOrientationListener;

import java.util.List;

public class MapActivity extends AppCompatActivity implements View.OnClickListener{


    /**
     * 定位功能
     * 1.LocationCli
     */
    private Context context;

    //控件
    private ImageView iv_myLocation;
    private EditText searchGoal;
    //地图相关
    private MapView mMapView;
    private BaiduMap mBaiduMap;

    //定位相关
    public LocationClient mLocationClient = null;
    private MyLocationListener myListener = new MyLocationListener();
    private boolean isFirstIn =true;
    private double mLatitude;
    private double mLongitude;
    //自定义定位图标
    private BitmapDescriptor mIconLocation;
    private MyOrientationListener myOrientationListener;
    private float mCurrentX;

    //覆盖物相关

    private BitmapDescriptor mMarker;
    //POI检索相关
    private PoiSearch mPoiSearch;
    private String SearchGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        //注意该方法要再setContentView方法之前实现
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_map);
        this.context = this;

        initView();

        initLocation();
        initMarker();

        //addOverlays();

        /*
        mBaiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {

                Bundle extraInfo = marker.getExtraInfo();
                final Building building = (Building) extraInfo.getSerializable("Building");




                TextView textView = new TextView(context);
                textView.setBackgroundResource(R.mipmap.location_tips);
                textView.setPadding(30,20,30,50);
                textView.setText(String.valueOf(building.getDeviceLocation()));
                textView.setTextColor(Color.WHITE);

                final LatLng latLng = marker.getPosition();

                InfoWindow infoWindow = new InfoWindow(textView, latLng, -47);

                mBaiduMap.showInfoWindow(infoWindow);

                return true;
            }
        });

        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                mBaiduMap.hideInfoWindow();
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {
                return false;
            }
        });*/


    }

    private void initMarker() {
        mMarker =BitmapDescriptorFactory.fromResource(R.mipmap.icon_location_hot);
    }

    /**
     * 添加覆盖物
     * @param Buildings
     */
    private void addOverlays(List<Building> Buildings) {
        mBaiduMap.clear();//清除一些图层
        LatLng latLng =null;
        Marker marker =null;
        OverlayOptions options;
        for (Building building:Buildings){
            //经纬度
            latLng = new LatLng(building.getLatitude(),building.getLongitude());
            //图标
            options = new MarkerOptions().position(latLng).icon(mMarker).zIndex(5);
            marker =(Marker) mBaiduMap.addOverlay(options);
            Bundle arg0 = new Bundle();
            arg0.putSerializable("Building",building);
            marker.setExtraInfo(arg0);
        }

        MapStatusUpdate msu =MapStatusUpdateFactory.newLatLng(latLng);
        mBaiduMap.setMapStatus(msu);

    }

    /**
     * POI检索
     */
    public void poiSearch(){
        mPoiSearch = PoiSearch.newInstance();
        mPoiSearch.setOnGetPoiSearchResultListener(mPoiSearchResultListener);

    }

    OnGetPoiSearchResultListener mPoiSearchResultListener = new OnGetPoiSearchResultListener() {
        //获得POI的检索结果，一般检索数据都是在这里获取
        @Override
        public void onGetPoiResult(PoiResult poiResult) {
            mBaiduMap.clear();
            /*
            if (poiResult != null && poiResult.error == PoiResult.ERRORNO.NO_ERROR) {//如果没有错误
                MyOverLay overlay = new MyOverLay(mBaiduMap, poiSearch);
                //设置数据,这里只需要一步，
                overlay.setData(poiResult);
                //添加到地图
                overlay.addToMap();
                //将显示视图拉倒正好可以看到所有POI兴趣点的缩放等级
                overlay.zoomToSpan();//计算工具
                //设置标记物的点击监听事件
                mBaiduMap.setOnMarkerClickListener(overlay);
                return;
            } else {
                Toast.makeText(getApplication(), "搜索不到你需要的信息！", Toast.LENGTH_SHORT).show();
            }*/
        }

        //获得POI的详细检索结果，如果发起的是详细检索，这个方法会得到回调(需要uid)
        @Override
        public void onGetPoiDetailResult(PoiDetailResult poiDetailResult) {
            /*
            if (poiDetailResult.error != SearchResult.ERRORNO.NO_ERROR) {
                Toast.makeText(getApplication(), "抱歉，未找到结果",
                        Toast.LENGTH_SHORT).show();
            } else {// 正常返回结果的时候，此处可以获得很多相关信息
                Toast.makeText(getApplication(), poiDetailResult.getName() + ": "
                                + poiDetailResult.getAddress(),
                        Toast.LENGTH_LONG).show();
            }*/
        }

        //获得POI室内检索结果
        @Override
        public void onGetPoiIndoorResult(PoiIndoorResult poiIndoorResult) {

        }
    };

    /*
    public void select(View view) {
        //获得Key
        String city = et_city.getText().toString();
        String key = et_key.getText().toString();
        //发起检索
        PoiCitySearchOption poiCity = new PoiCitySearchOption();
        poiCity.keyword(key).city(city);
        mPoiSearch.searchInCity(poiCity);
    }*/




    private void initView() {
        //获取控件引用
        iv_myLocation = findViewById(R.id.map_myLocation);
        iv_myLocation.setOnClickListener(this);
        searchGoal = findViewById(R.id.tv_map_search);
        searchGoal.setFocusable(false);
        searchGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MapActivity.this, MapSearchActivity.class));
            }
        });

        //获取地图控件引用
        mMapView = findViewById(R.id.bmapView2);
        mBaiduMap = mMapView.getMap();
        //设置地图放大级别
        MapStatusUpdate mapUpdate = MapStatusUpdateFactory.zoomTo(15.0f);
        //更改地图状态
        mBaiduMap.setMapStatus(mapUpdate);
    }

    private void initLocation() {
        //声明LocationClient类
        mLocationClient = new LocationClient(getApplicationContext());
        //注册监听函数
        mLocationClient.registerLocationListener(myListener);

        LocationClientOption option = new LocationClientOption();
        //可选，设置定位模式，默认高精度
        //LocationMode.Hight_Accuracy：高精度；
        //LocationMode. Battery_Saving：低功耗；
        //LocationMode. Device_Sensors：仅使用设备；
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);

        //可选，设置返回经纬度坐标类型，默认gcj02
        //gcj02：国测局坐标；
        //bd09ll：百度经纬度坐标；
        //bd09：百度墨卡托坐标；
        //海外地区定位，无需设置坐标类型，统一返回wgs84类型坐标
        option.setCoorType("bd09ll");

        //可选，设置发起定位请求的间隔，int类型，单位ms
        // 如果设置为0，则代表单次定位，即仅定位一次，默认为0
        // 如果设置非0，需设置1000ms以上才有效
        option.setScanSpan(1000);

        //可选，设置是否使用gps，默认false
        //使用高精度和仅用设备两种定位模式的，参数必须设置为true
        option.setOpenGps(true);

        //可选，设置是否当GPS有效时按照1S/1次频率输出GPS结果，默认false
        option.setLocationNotify(true);

        //可选，定位SDK内部是一个service，并放到了独立进程。
        // 设置是否在stop的时候杀死这个进程，默认（建议）不杀死，即setIgnoreKillProcess(true)
        option.setIgnoreKillProcess(false);

        //可选，设置是否收集Crash信息，默认收集，即参数为false
        option.SetIgnoreCacheException(false);

        //可选，7.2版本新增能力
        // 如果设置了该接口，首次启动定位时，会先判断当前WiFi是否超出有效期，若超出有效期，会先重新扫描WiFi，然后定位
        option.setWifiCacheTimeOut(5*60*1000);

        //可选，设置是否需要过滤GPS仿真结果，默认需要，即参数为false
        option.setEnableSimulateGps(false);

        //是否需要地址信息，默认为不需要，即参数为false
        option.setIsNeedAddress(true);

        //mLocationClient为第二步初始化过的LocationClient对象
        //需将配置好的LocationClientOption对象，通过setLocOption方法传递给LocationClient对象使用
        //更多LocationClientOption的配置，请参照类参考中LocationClientOption类的详细说明
        mLocationClient.setLocOption(option);
        //初始化图标
        mIconLocation = BitmapDescriptorFactory.fromResource(R.mipmap.icon_navigation);
        //初始化方向传感器
        myOrientationListener = new MyOrientationListener(context);

        myOrientationListener.setOnOrientationListener(new MyOrientationListener.OnOrientationListener() {
            @Override
            public void onOrientationChanged(float x) {
                mCurrentX=x;
            }
        });

    }
    //定位的回调方法
    public class MyLocationListener extends BDAbstractLocationListener {
        @Override
        //定位成功后的回调
        public void onReceiveLocation(BDLocation location){
            //此处的BDLocation为定位结果信息类，通过它的各种get方法可获取定位相关的全部结果
            //以下只列举部分获取经纬度相关（常用）的结果信息
            //更多结果信息获取说明，请参照类参考中BDLocation类中的说明

            MyLocationData data= new MyLocationData.Builder()
                    .direction(mCurrentX)//方向
                    .accuracy(location.getRadius())//精度
                    .latitude(location.getLatitude())
                    .longitude(location.getLongitude())
                    .build();
            mBaiduMap.setMyLocationData(data);

            //设置自定义图标
            MyLocationConfiguration configuration =new MyLocationConfiguration
                    (MyLocationConfiguration.LocationMode.NORMAL,true,mIconLocation);
            mBaiduMap.setMyLocationConfiguration(configuration);

            //更新经纬度
            mLatitude = location.getLatitude();    //获取纬度信息
            mLongitude = location.getLongitude();    //获取经度信息

            //获取位置信息
            String addr = location.getAddrStr();    //获取详细地址信息
            String country = location.getCountry();    //获取国家
            String province = location.getProvince();    //获取省份
            String city = location.getCity();    //获取城市
            String district = location.getDistrict();    //获取区县
            String street = location.getStreet();    //获取街道信息

            //获取经纬度坐标类型，以LocationClientOption中设置过的坐标类型为准
            String coorType = location.getCoorType();
            //获取定位类型、定位错误返回码，具体信息可参照类参考中BDLocation类中的说明
            int errorCode = location.getLocType();

            L.e(addr);


            if (isFirstIn){
                //获取定位坐标
                LatLng latLng =new LatLng(location.getLatitude(),location.getLongitude());
                //设置定位的位置
                MapStatusUpdate msu =MapStatusUpdateFactory.newLatLng(latLng);
                //更新地图
                mBaiduMap.setMapStatus(msu);
                isFirstIn=false;
            }


        }
    }

    /**
     * 定位到我的位置
     */
    private void centerToMyLocation() {
        //获取定位坐标
        LatLng latLng =new LatLng(mLatitude,mLongitude);
        //设置定位的位置
        MapStatusUpdate msu = MapStatusUpdateFactory.newLatLng(latLng);
        //更新地图
        mBaiduMap.setMapStatus(msu);
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.map_myLocation:
                centerToMyLocation();
                break;

        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();

        SearchGoal=getIntent().getStringExtra("data");
        searchGoal.setText(SearchGoal);

        //必须开启我们的定位
        mBaiduMap.setMyLocationEnabled(true);
        if(!mLocationClient.isStarted())
            mLocationClient.start();
        //开启方向传感器
        myOrientationListener.start();
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //关闭定位
        mBaiduMap.setMyLocationEnabled(false);
        mLocationClient.stop();
        //停止方向传感器
        myOrientationListener.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
    }
}
