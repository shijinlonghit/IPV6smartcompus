package com.example.samrtcampus.ipv6smartcampus2.DataClass;

import cn.bmob.v3.BmobObject;

/**
 * Created by yangz on 2018/5/21.
 */

public class DormitoryInfo extends BmobObject {
    private String DormitoryTemperature;
    private String DormitoryElectricity;
    private String DormitoryLight;
    private String DormitoryNet;

    public String getDormitoryTemperature() {
        return DormitoryTemperature;
    }

    public void setDormitoryTemperature(String dormitoryTemperature) {
        DormitoryTemperature = dormitoryTemperature;
    }

    public String getDormitoryElectricity() {
        return DormitoryElectricity;
    }

    public void setDormitoryElectricity(String dormitoryElectricity) {
        DormitoryElectricity = dormitoryElectricity;
    }

    public String getDormitoryLight() {
        return DormitoryLight;
    }

    public void setDormitoryLight(String dormitoryLight) {
        DormitoryLight = dormitoryLight;
    }

    public String getDormitoryNet() {
        return DormitoryNet;
    }

    public void setDormitoryNet(String dormitoryNet) {
        DormitoryNet = dormitoryNet;
    }
}
