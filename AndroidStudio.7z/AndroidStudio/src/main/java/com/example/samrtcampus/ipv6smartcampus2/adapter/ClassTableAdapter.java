package com.example.samrtcampus.ipv6smartcampus2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.entity.ClassInformation;

import java.util.List;

/**
 * Created by yangz on 2018/5/2.
 */

public class ClassTableAdapter extends BaseAdapter {


    private List<ClassInformation> list;
    private LayoutInflater inflater;

    public ClassTableAdapter(Context context, List<ClassInformation> list){
        this.list = list;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        int ret = 0;
        if(list!=null){
            ret = list.size();
        }
        return ret;
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ClassInformation classInformation = (ClassInformation) this.getItem(i);

        ViewHolder viewHolder;

        if(view == null){

            viewHolder = new ViewHolder();

            view = inflater.inflate(R.layout.item_lv_class, null);
            viewHolder.classTime = view.findViewById(R.id.text_classTime);
            viewHolder.className = view.findViewById(R.id.text_className);
            viewHolder.classOrder = view.findViewById(R.id.text_classOrder);


            view.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.classTime.setText(classInformation.getClassTime());
        viewHolder.classTime.setTextSize(13);
        viewHolder.className.setText(classInformation.getClassName());
        viewHolder.className.setTextSize(13);
        viewHolder.classOrder.setText(classInformation.getClassOrder());
        viewHolder.classOrder.setTextSize(13);

        return view;
    }

    public static class ViewHolder{
        public TextView classTime;
        public TextView className;
        public TextView classOrder;
    }
}
