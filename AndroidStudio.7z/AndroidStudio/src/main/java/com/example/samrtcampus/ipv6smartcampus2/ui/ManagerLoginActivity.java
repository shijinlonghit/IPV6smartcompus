package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.R;

/**
 * Created by yangz on 2018/6/24.
 */

public class ManagerLoginActivity extends AppCompatActivity implements View.OnClickListener{
    private Button button1;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_managerlogin);

        initView();
    }

    private void initView() {
        button1=findViewById(R.id.energy_map_login);
        button1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.energy_map_login:
                Toast.makeText(ManagerLoginActivity.this,"密码错误请重新输入",Toast.LENGTH_SHORT).show();
        }
    }
}
