package com.example.samrtcampus.ipv6smartcampus2.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.RequiredDevice;
import com.example.samrtcampus.ipv6smartcampus2.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;

/**
 * Created by yangz on 2018/5/2.
 */


public class DormitoryDeviceFragment extends Fragment {
    //定义控件
    private EditText et_deviceName;
    private EditText et_deviceInfo;
    private Button btn_commit;

    //定义变量
    private String DeviceName;
    private String DeviceInfo;
    //定义载体传值
    private HashMap<String,String > mHashMap;
    private List<Map<String,String>> mapList;
    private List<String> mList;
    //定义listview
    private ListView listView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dormitory_device,null);
        findView(view);
        return view;
    }

    private void findView(View view) {
        et_deviceName = view.findViewById(R.id.require_device);
        et_deviceInfo = view.findViewById(R.id.require_information);
        btn_commit = view.findViewById(R.id.require_commit);
        //listView = view.findViewById(R.id.dormitory_device_list);

        btn_commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeviceName=et_deviceName.getText().toString().trim();
                DeviceInfo=et_deviceInfo.getText().toString().trim();

                if (!TextUtils.isEmpty(DeviceName)&!TextUtils.isEmpty(DeviceInfo)){
                    RequiredDevice requiredDevice =new RequiredDevice();
                    requiredDevice.setDeviceName(DeviceName);
                    requiredDevice.setDeviceInfo(DeviceInfo);
                    requiredDevice.save(new SaveListener<String>() {
                        @Override
                        public void done(String s, BmobException e) {
                            if (e==null){
                                Toast.makeText(DormitoryDeviceFragment.this.getActivity(),"提交成功",Toast.LENGTH_SHORT).show();
                            }else {
                                Toast.makeText(DormitoryDeviceFragment.this.getActivity(),"提交失败",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else {
                    Toast.makeText(DormitoryDeviceFragment.this.getActivity(),"请输入需维修的设备及设备信息",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //创建list用于存放mHashmap
        mapList = new ArrayList<>();
        BmobQuery<RequiredDevice> query = new BmobQuery<RequiredDevice>();
        //查询功能给listview适配
        query.findObjects(new FindListener<RequiredDevice>() {
            @Override
            public void done(List<RequiredDevice> list, BmobException e) {
                if (e==null){
                    for (final RequiredDevice requiredDevice : list) {
                        //初始化HashMap
                        mHashMap = new HashMap<>();
                        mHashMap.put("DeviceName",requiredDevice.getDeviceName());
                        mHashMap.put("Status",requiredDevice.getStatus());
                        mHashMap.put("Date",requiredDevice.getCreatedAt().toString());
                        mapList.add(mHashMap);

                    }
                    mList=new ArrayList<String>();
                    mList.add(mapList.get(0).get("DeviceName"));




                   // DormitoryDeviceAdapter adapter = new DormitoryDeviceAdapter(DormitoryDeviceFragment.this.getActivity(),mList);
                   // listView.setAdapter(adapter);
                }else{

                }
            }
        });

    }
}
