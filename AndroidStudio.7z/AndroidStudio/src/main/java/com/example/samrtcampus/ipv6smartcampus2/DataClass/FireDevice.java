package com.example.samrtcampus.ipv6smartcampus2.DataClass;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.datatype.BmobFile;

/**
 * Created by yangz on 2018/5/14.
 */

public class FireDevice extends BmobObject{
    private double Latitude;
    private double Longitude;
    private String DeviceNumber;
    private String DeviceType;
    private String DeviceDescription;
    private String Temperature;
    private String Status;
    private String DeviceQValue;
    private BmobFile DeviceImg;



    public BmobFile getDeviceImg() {
        return DeviceImg;
    }

    public void setDeviceImg(BmobFile deviceImg) {
        DeviceImg = deviceImg;
    }



    public double getLatitude() {
        return Latitude;
    }

    public void setLatitude(double latitude) {
        Latitude = latitude;
    }

    public double getLongitude() {
        return Longitude;
    }

    public void setLongitude(double longitude) {
        Longitude = longitude;
    }

    public String getDeviceNumber() {
        return DeviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        DeviceNumber = deviceNumber;
    }

    public String getDeviceDescription() {
        return DeviceDescription;
    }

    public void setDeviceDescription(String deviceDescription) {
        DeviceDescription = deviceDescription;
    }

    public String getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(String deviceType) {
        DeviceType = deviceType;
    }



    public String getTemperature() {
        return Temperature;
    }

    public void setTemperature(String temperature) {
        Temperature = temperature;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getDeviceQValue() {
        return DeviceQValue;
    }

    public void setDeviceQValue(String deviceQValue) {
        DeviceQValue = deviceQValue;
    }
}
