package com.example.samrtcampus.ipv6smartcampus2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.utils.StaticClass;
import com.example.samrtcampus.ipv6smartcampus2.utils.UtilTools;

public class SplashActivity extends AppCompatActivity {

    /**
     * 1.延迟4000ms
     * 2.自定义字体
     * 3.Activity全屏主题
     * @param savedInstanceState
     */
    private TextView tv_splashhit;

    //初始化Handler，并跳转至登录界面
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case StaticClass.HANDLER_SPLASH:
                    startActivity(new Intent(SplashActivity.this,LoginActivity.class));
                    finish();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        initView();
    }

    //初始化View
    private void initView() {
        //延时4000ms
        handler.sendEmptyMessageDelayed(StaticClass.HANDLER_SPLASH,3000);

        tv_splashhit= findViewById(R.id.tv_splash_hit);
        //设置字体
        UtilTools.setFont(this,tv_splashhit);


    }

}
