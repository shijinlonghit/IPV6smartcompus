package com.example.samrtcampus.ipv6smartcampus2.entity;


import com.example.samrtcampus.ipv6smartcampus2.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangz on 2018/5/3.
 */

public class MarkerInfo implements Serializable{

    private static final long serialVersionUID = 4424769252411342328L;
    private double latitude;
    private double longitude;



    private int imgID;
    private int deviceNumber;
    private String deviceType;
    private String deviceLocation;
    private String time;

    public static List<MarkerInfo> Markerinfos= new ArrayList<MarkerInfo>();



    static {
        Markerinfos.add(new MarkerInfo(45.745923,126.637833,R.mipmap.a1000001,1000001,"热力表","16公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.74719,126.637329,R.mipmap.a1000002,1000002,"热力表","4公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.74642,126.637886,R.mipmap.a1000003,1000003,"热力表","13公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.751618,126.638654,R.mipmap.a1000003,1000004,"热力表","图书馆","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.75124,126.638277,R.mipmap.a1000003,1000005,"热力表","图书馆","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.750939,126.639175,R.mipmap.a1000003,1000006,"热力表","图书馆","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.749347,126.64002,R.mipmap.a1000003,1000007,"热力表","学士楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.749347,126.639113,R.mipmap.a1000003,1000008,"热力表","学士楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.749555,126.639804,R.mipmap.a1000003,1000009,"热力表","学士楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.752297,126.639571,R.mipmap.a1000003,1000010,"热力表","电机楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.752586,126.638969,R.mipmap.a1000003,1000011,"热力表","电机楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.752951,126.638322,R.mipmap.a1000003,1000012,"热力表","电机楼","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.747523,126.637765,R.mipmap.a1000003,1000013,"热力表","4公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.747247,126.637262,R.mipmap.a1000003,1000014,"热力表","4公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.746379,126.638071,R.mipmap.a1000003,1000015,"热力表","13公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.746574,126.637747,R.mipmap.a1000003,1000016,"热力表","13公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.745549,126.637406,R.mipmap.a1000003,1000017,"热力表","16公寓","2018.04.01"));
        Markerinfos.add(new MarkerInfo(45.746127,126.637514,R.mipmap.a1000003,1000018,"热力表","16公寓","2018.04.01"));
    }

    public MarkerInfo(double latitude, double longitude, int imgID, int deviceNumber, String deviceType, String deviceLocation, String time) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.imgID=imgID;
        this.deviceNumber = deviceNumber;
        this.deviceType = deviceType;
        this.deviceLocation = deviceLocation;
        this.time = time;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }


    public int getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(int deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public int getImgID() {
        return imgID;
    }

    public void setImgID(int imgID) {
        this.imgID = imgID;
    }



}
