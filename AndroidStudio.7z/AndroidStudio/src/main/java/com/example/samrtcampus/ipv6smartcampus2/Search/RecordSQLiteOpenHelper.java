package com.example.samrtcampus.ipv6smartcampus2.Search;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by yangz on 2018/5/20.
 */

public class RecordSQLiteOpenHelper extends SQLiteOpenHelper{
    private static String name = "temp.db";
    private static Integer version = 1;

    public RecordSQLiteOpenHelper(Context context) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 打开数据库 & 建立一个名为records的表，里面只有一列name来存储历史记录：
        db.execSQL("create table records(id integer primary key autoincrement,name varchar(200))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    /*
    作者：Carson_Ho
    链接：https://www.jianshu.com/p/590f00025de3
    來源：简书
    著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
    */
}
