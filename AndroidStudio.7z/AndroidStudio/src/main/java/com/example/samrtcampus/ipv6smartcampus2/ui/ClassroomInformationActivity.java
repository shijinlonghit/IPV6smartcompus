package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.ClassInfo;
import com.example.samrtcampus.ipv6smartcampus2.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

/**
 * Created by yangz on 2018/5/20.
 */

public class ClassroomInformationActivity extends AppCompatActivity implements View.OnClickListener{

    public static final int BMOB_CLASSINFO = 103;


    //定义控件
    private TextView classLocation;
    private TextView className;
    private TextView teacherName;
    private TextView classContent;
    private TextView classDate;
    //考勤相关
    private TextView locationCheck;
    private Button faceCheck;
    private Button commit;

    //定义变量
    private String ClassPosition;
    private String ClassName;
    private String Date;
    private String Teacher;
    private String ClassContent;

    //查询相关
    //定义载体传值
    private HashMap<String,String > mHashMap;
    private List<Map<String,String>> mapList;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case BMOB_CLASSINFO:
                    teacherName.setText(Teacher);
                    classContent.setText(ClassContent);
                    break;
            }
        }
    };
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classroom_information);

        initView();
        initData();
        setView();

    }

    private void setView() {
        classLocation.setText(ClassPosition);
        className.setText(ClassName);
        classDate.setText(Date);

    }

    private void initView() {
        classLocation = findViewById(R.id.classroom_position);
        className = findViewById(R.id.classroom_name);
        teacherName = findViewById(R.id.classroom_teacher);
        classContent = findViewById(R.id.classroom_content);
        classDate = findViewById(R.id.date);
        locationCheck = findViewById(R.id.location_check);
        locationCheck.setOnClickListener(this);

        faceCheck = findViewById(R.id.face_check);
        faceCheck.setOnClickListener(this);
        commit = findViewById(R.id.commit);
        commit.setOnClickListener(this);

    }

    private void initData() {
        Date =getIntent().getStringExtra("Date");
        ClassPosition = getIntent().getStringExtra("Class");
        ClassName = getIntent().getStringExtra("Classdata");

        Query();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.face_check:
                break;
            case R.id.commit:
                break;
            case R.id.location_check:
                break;
        }

    }

    public void Query(){
        //创建list用于存放mHashmap
        mapList = new ArrayList<>();

        //查询
        BmobQuery<ClassInfo> query = new BmobQuery<ClassInfo>();
        List<BmobQuery<ClassInfo>> and = new ArrayList<BmobQuery<ClassInfo>>();
        //日期
        BmobQuery<ClassInfo> q1 = new BmobQuery<ClassInfo>();
        q1.addWhereEqualTo("Date",Date);
        and.add(q1);
        //教室
        BmobQuery<ClassInfo> q2 = new BmobQuery<ClassInfo>();
        q2.addWhereEqualTo("ClassPosition",ClassPosition);
        and.add(q2);
        //课程
        BmobQuery<ClassInfo> q3 = new BmobQuery<ClassInfo>();
        q1.addWhereEqualTo("ClassName",ClassName);
        and.add(q3);
        //组合条件
        query.and(and);
        query.findObjects(new FindListener<ClassInfo>() {
            @Override
            public void done(List<ClassInfo> list, BmobException e) {
                if (e==null){
                    for (final ClassInfo classInfo : list){
                        //初始化HashMap
                        mHashMap = new HashMap<>();
                        mHashMap.put("ClassContent",classInfo.getClassContent());//第一节
                        mHashMap.put("Teacher",classInfo.getTeacher());//第二节
                        mapList.add(mHashMap);

                    }
                }else {
                    Toast.makeText(ClassroomInformationActivity.this,"查询失败",Toast.LENGTH_SHORT).show();
                    Log.i("Bmob","失败:"+e.getMessage()+","+e.getErrorCode());
                }

                Teacher = mapList.get(0).get("Teacher");
                ClassContent = mapList.get(0).get("ClassContent");

                //Toast.makeText(ClassroomActivity.this,"查询成功",Toast.LENGTH_LONG).show();

                Message msg =Message.obtain();
                msg.what= BMOB_CLASSINFO;
                mHandler.sendMessage(msg);

            }
        });
    }
}
