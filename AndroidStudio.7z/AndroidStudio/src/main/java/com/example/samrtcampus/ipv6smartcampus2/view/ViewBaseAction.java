package com.example.samrtcampus.ipv6smartcampus2.view;

/**
 * Created by yangz on 2018/5/20.
 */

public interface ViewBaseAction {

    public void hide();


    public void show();
}
