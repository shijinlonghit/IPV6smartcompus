package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.FireDevice;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.utils.ShareUtils;
import com.squareup.picasso.Picasso;
//import com.squareup.picasso.Picasso;


import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.UpdateListener;

/**
 * Created by yangz on 2018/5/15.
 */

public class FireDeviceActivity extends AppCompatActivity implements View.OnClickListener{

    public static final int BMOB_DATA = 101;
    //定义变量
    private String deviceNumber;
    private String deviceType;
    private String deviceDescription;
    private String imgURL;
    private String temperature;
    private String heat;
    private String status;
    private String objectId;

    //定义查询时间变量
    private String currentTime;
    private String currentTimeFinal;
    private String chooseTime;
    private String chooseTimeFinal;

    //定义载体传值
    private HashMap<String,String > mHashMap;
    private List<Map<String,String>> mapList;

    //声明控件
    private TextView fire_device_number;
    private TextView fire_device_type;
    private TextView fire_device_desc;
    private TextView fire_device_Heat;
    private TextView fire_device_temp;
    private ImageView fire_device_Img;
    private Switch fire_device_sw;


    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Log.i("mHandler",""+msg.what);
            switch (msg.what){
                case BMOB_DATA:
                    fire_device_number.setText(deviceNumber);
                    fire_device_type.setText(deviceType);
                    fire_device_desc.setText(deviceDescription);
                    fire_device_Heat.setText(heat);
                    fire_device_temp.setText(temperature);
                    Picasso.with(FireDeviceActivity.this).load(imgURL).into(fire_device_Img);

                    if (status.equals("1")){
                        fire_device_sw.setChecked(true);
                    }else if (status.equals("0")){
                        fire_device_sw.setChecked(false);
                    }
                    //Toast.makeText(FireDeviceActivity.this,status,Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fire_device);

        initView();

        initData();

        setView();


    }



    private void initData() {
        deviceNumber = getIntent().getStringExtra("data");
        currentTime="2018-05-15";
        //创建list用于存放mHashmap
        mapList = new ArrayList<>();

        //查询
        BmobQuery<FireDevice> query = new BmobQuery<FireDevice>();
        List<BmobQuery<FireDevice>> and = new ArrayList<BmobQuery<FireDevice>>();
        //时间大于00：00:00
        BmobQuery<FireDevice> q1 = new BmobQuery<FireDevice>();
        String start = currentTime+" 00:00:00";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date =null;
        try{
            date=sdf.parse(start);
        } catch (ParseException e){
            e.printStackTrace();
        }
        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(date));
        and.add(q1);
        //小于23：59：59
        BmobQuery<FireDevice> q2 = new BmobQuery<FireDevice>();
        String end = currentTime+" 23:59:59";
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1  = null;
        try {
            date1 = sdf1.parse(end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(date1));
        and.add(q2);
        //设备号
        query.addWhereEqualTo("DeviceNumber",deviceNumber);
        //组合条件
        query.and(and);
        query.findObjects(new FindListener<FireDevice>() {
            @Override
            public void done(List<FireDevice> list, BmobException e) {
                if (e==null){


                    for (final FireDevice fireDevice : list){
                        //初始化HashMap
                        mHashMap = new HashMap<>();
                        mHashMap.put("DeviceType",fireDevice.getDeviceType());//设备类型
                        mHashMap.put("DeviceDescription",fireDevice.getDeviceDescription());//设备位置描述
                        mHashMap.put("imgURL",fireDevice.getDeviceImg().getFileUrl());//得到照片URL
                        mHashMap.put("Temperature",fireDevice.getTemperature());//温度
                        mHashMap.put("Heat",fireDevice.getDeviceQValue());//热量
                        mHashMap.put("Status",fireDevice.getStatus());//开关状态，0或1
                        mHashMap.put("ObjectId",fireDevice.getObjectId());//数据ID
                        mapList.add(mHashMap);

                    }


                }else {
                    Log.i("Bmob","失败:"+e.getMessage()+","+e.getErrorCode());
                }
                deviceType=mapList.get(0).get("DeviceType");
                deviceDescription=mapList.get(0).get("DeviceDescription");
                imgURL=mapList.get(0).get("imgURL");
                temperature=mapList.get(0).get("Temperature");
                heat=mapList.get(0).get("Heat");
                status=mapList.get(0).get("Status");
                objectId=mapList.get(0).get("ObjectId");

                Message msg =Message.obtain();
                msg.what= BMOB_DATA;
                mHandler.sendMessage(msg);

            }
        });




    }

    private void initView() {
        fire_device_number=findViewById(R.id.fire_device_number);
        fire_device_type=findViewById(R.id.fire_device_type);
        fire_device_desc=findViewById(R.id.fire_device_desc);
        fire_device_Heat=findViewById(R.id.fire_device_heat);
        fire_device_temp=findViewById(R.id.fire_device_temp);
        fire_device_Img=findViewById(R.id.fire_device_Img);
        fire_device_sw=findViewById(R.id.fire_device_sw);
        fire_device_sw.setOnClickListener(this);




    }

    private void setView() {

        /*
        //不能直接在主线程中进行从网络端获取图片，而需要单独开一个子线程完成从网络端获取图片
        new Thread(new Runnable() {
            @Override
            public void run() {
                //根据表中图片的url地址来得到图片（Bitmap类型）
                final Bitmap bitmap=getPicture(imgURL);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //将图片放到视图当中
                fire_device_Img.post(new Runnable() {
                    @Override
                    public void run() {
                        fire_device_Img.setImageBitmap(bitmap);
                    }
                });


            }
        }).start();*/


    }
    public Bitmap getPicture(String path){
        Bitmap bm = null;
        try{
            URL url=new URL(path);
            URLConnection connection=url.openConnection();
            connection.connect();
            InputStream inputStream=connection.getInputStream();
            bm= BitmapFactory.decodeStream(inputStream);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bm;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fire_device_sw:
                //切换相反
                fire_device_sw.setSelected(!fire_device_sw.isSelected());
                //保存状态
                ShareUtils.getBoolean(this,"isSpeak",fire_device_sw.isChecked());
                //更新Status状态
                FireDevice fireDevice = new FireDevice();
                if (fire_device_sw.isChecked()){
                    fireDevice.setStatus(this.getString(R.string.on));
                }else if (!fire_device_sw.isChecked()){
                    fireDevice.setStatus(this.getString(R.string.off));
                }

                fireDevice.update(objectId, new UpdateListener() {
                    @Override
                    public void done(BmobException e) {
                        if (e==null){
                            Log.i("bmob","更新成功");
                            //Toast.makeText(FireDeviceActivity.this,"更新成功",Toast.LENGTH_LONG).show();
                        }else {
                            Log.i("bmob","更新失败："+e.getMessage()+","+e.getErrorCode());
                            //Toast.makeText(FireDeviceActivity.this,"更新失败",Toast.LENGTH_LONG).show();
                        }
                    }
                });
                break;

        }
    }
}
