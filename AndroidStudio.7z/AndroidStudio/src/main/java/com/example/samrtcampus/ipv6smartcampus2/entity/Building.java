package com.example.samrtcampus.ipv6smartcampus2.entity;

import com.example.samrtcampus.ipv6smartcampus2.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangz on 2018/6/24.
 */

public class Building implements Serializable {
    private static final long serialVersionUID = 44L;
    private double latitude;
    private double longitude;



    private int imgID;
    private int deviceNumber;
    private String deviceType;
    private String deviceLocation;
    private String time;

    public static List<Building> Buildings= new ArrayList<Building>();



    static {
        Buildings.add(new Building(45.745923,126.637833, R.mipmap.a1000001,1000001,"热力表","16公寓","2018.04.01"));
        Buildings.add(new Building(45.74719,126.637329,R.mipmap.a1000002,1000002,"热力表","4公寓","2018.04.01"));
        Buildings.add(new Building(45.74642,126.637886,R.mipmap.a1000003,1000003,"热力表","13公寓","2018.04.01"));
        Buildings.add(new Building(45.751618,126.638654,R.mipmap.a1000003,1000004,"热力表","图书馆","2018.04.01"));
        Buildings.add(new Building(45.749347,126.64002,R.mipmap.a1000003,1000007,"热力表","学士楼","2018.04.01"));
        Buildings.add(new Building(45.752297,126.639571,R.mipmap.a1000003,1000010,"热力表","电机楼","2018.04.01"));

    }

    public Building(double latitude, double longitude, int imgID, int deviceNumber, String deviceType, String deviceLocation, String time) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.imgID=imgID;
        this.deviceNumber = deviceNumber;
        this.deviceType = deviceType;
        this.deviceLocation = deviceLocation;
        this.time = time;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getImgID() {
        return imgID;
    }

    public void setImgID(int imgID) {
        this.imgID = imgID;
    }

    public int getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(int deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static List<Building> getBuildings() {
        return Buildings;
    }

    public static void setBuildings(List<Building> buildings) {
        Buildings = buildings;
    }
}
