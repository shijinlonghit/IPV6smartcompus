package com.example.samrtcampus.ipv6smartcampus2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;

import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.example.samrtcampus.ipv6smartcampus2.entity.MarkerInfo;

import com.example.samrtcampus.ipv6smartcampus2.ui.FireDeviceActivity;
import com.example.samrtcampus.ipv6smartcampus2.ui.FireListActivity;
import com.example.samrtcampus.ipv6smartcampus2.ui.SearchActivity;

import java.util.List;

import static com.example.samrtcampus.ipv6smartcampus2.entity.MarkerInfo.Markerinfos;


public class EnergyMapActivity extends AppCompatActivity implements View.OnClickListener{



    private Context context;

    private String fireDeviceNumber;

    //控件
    private Button btn_energy_list;
    private RelativeLayout markerInfo;
    private ImageView energy_search;
    //地图相关
    private MapView mMapView;
    private BaiduMap mBaiduMap;


    //覆盖物相关
    //覆盖物
    private BitmapDescriptor mMarker;
    //覆盖物信息布局
    private RelativeLayout mMarkerLy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在使用SDK各组件之前初始化context信息，传入ApplicationContext
        //注意该方法要再setContentView方法之前实现
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_energy_map);

        this.context = this;

        initView();

        initMarker();

        addOverlays(Markerinfos);

        mBaiduMap.setOnMarkerClickListener(new BaiduMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {

                Bundle extraInfo = marker.getExtraInfo();
                final MarkerInfo markerInfo = (MarkerInfo) extraInfo.getSerializable("MarkerInfo");

                final ImageView iv = mMarkerLy.findViewById(R.id.energy_device_img);
                TextView deviceNumber = mMarkerLy.findViewById(R.id.energy_device_id);
                TextView deviceType = mMarkerLy.findViewById(R.id.energy_device_type);

                iv.setImageResource(markerInfo.getImgID());
                deviceNumber.setText(String.valueOf(markerInfo.getDeviceNumber()));
                fireDeviceNumber=markerInfo.getDeviceNumber()+"";
                Log.v("fireDeviceNumber",fireDeviceNumber);
                deviceType.setText(markerInfo.getDeviceType());

                TextView textView = new TextView(context);
                textView.setBackgroundResource(R.mipmap.location_tips);
                textView.setPadding(30,20,30,50);
                textView.setText(String.valueOf(markerInfo.getDeviceNumber()));
                textView.setTextColor(Color.WHITE);

                final LatLng latLng = marker.getPosition();

                InfoWindow infoWindow = new InfoWindow(textView, latLng, -47);

                mBaiduMap.showInfoWindow(infoWindow);
                mMarkerLy.setVisibility(View.VISIBLE);

                return true;
            }
        });

        mBaiduMap.setOnMapClickListener(new BaiduMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                mBaiduMap.hideInfoWindow();
                mMarkerLy.setVisibility(View.GONE);
            }

            @Override
            public boolean onMapPoiClick(MapPoi mapPoi) {
                return false;
            }
        });

    }

    private void initMarker() {
        mMarker =BitmapDescriptorFactory.fromResource(R.mipmap.icon_location_hot);
        mMarkerLy = findViewById(R.id.marker_Info);
    }


    private void initView() {
        //获取控件引用
        btn_energy_list = findViewById(R.id.energy_list);
        btn_energy_list.setOnClickListener(this);
        markerInfo = findViewById(R.id.marker_Info);
        markerInfo.setOnClickListener(this);
        energy_search=findViewById(R.id.energy_search);
        energy_search.setOnClickListener(this);


        //获取地图控件引用
        mMapView = findViewById(R.id.bmapView);
        mBaiduMap = mMapView.getMap();
        //设置地图放大级别
        MapStatusUpdate mapUpdate = MapStatusUpdateFactory.zoomTo(15.0f);
        //更改地图状态
        mBaiduMap.setMapStatus(mapUpdate);
    }






    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.energy_list:
                startActivity(new Intent(EnergyMapActivity.this,FireListActivity.class));
                finish();
                break;
            case R.id.marker_Info:
                Intent intent = new Intent(EnergyMapActivity.this,FireDeviceActivity.class);
                intent.putExtra("data",fireDeviceNumber);
                startActivity(intent);
                break;
            case R.id.energy_search:
                startActivity(new Intent(EnergyMapActivity.this, SearchActivity.class));
                break;
        }
    }




    /**
     * 添加覆盖物
     * @param Markerinfos
     */
    private void addOverlays(List<MarkerInfo> Markerinfos) {
        mBaiduMap.clear();//清除一些图层
        LatLng latLng =null;
        Marker marker =null;
        OverlayOptions options;
        for (MarkerInfo markerInfo:Markerinfos){
            //经纬度
            latLng = new LatLng(markerInfo.getLatitude(),markerInfo.getLongitude());
            //图标
            options = new MarkerOptions().position(latLng).icon(mMarker).zIndex(5);
            marker =(Marker) mBaiduMap.addOverlay(options);
            Bundle arg0 = new Bundle();
            arg0.putSerializable("MarkerInfo",markerInfo);
            marker.setExtraInfo(arg0);
        }

        MapStatusUpdate msu =MapStatusUpdateFactory.newLatLng(latLng);
        mBaiduMap.setMapStatus(msu);

    }





    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
        //必须开启我们的定位
        mBaiduMap.setMyLocationEnabled(true);
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //关闭定位
        mBaiduMap.setMyLocationEnabled(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
    }
}

