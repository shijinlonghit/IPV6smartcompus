package com.example.samrtcampus.ipv6smartcampus2.entity;

/**
 * Created by yangz on 2018/5/2.
 */

public class ClassInformation {
        private String classTime;
        private String classOrder;
        private String className;

        public ClassInformation() {
            super();
        }

        public ClassInformation(String classTime,  String classOrder,String className) {
            super();
            this.classTime = classTime;
            this.className = className;
            this.classOrder = classOrder;

        }


    public String getClassTime() {
        return classTime;
    }

    public String getClassName() {
            return className;
        }

    public void setClassName(String className) {
            this.className = className;
        }

    public void setClassTime(String classTime) {
        this.classTime = classTime;
    }

    public String getClassOrder() {
        return classOrder;
    }

    public void setClassOrder(String classOrder) {
        this.classOrder = classOrder;
    }
}

