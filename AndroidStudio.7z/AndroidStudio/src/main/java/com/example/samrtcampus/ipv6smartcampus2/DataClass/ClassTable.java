package com.example.samrtcampus.ipv6smartcampus2.DataClass;

import cn.bmob.v3.BmobObject;

/**
 * Created by yangz on 2018/5/20.
 */

public class ClassTable extends BmobObject {
    private String Date;
    private String ClassName;
    private String ClassName1;
    private String ClassName2;
    private String ClassName3;
    private String ClassName4;
    private String ClassName5;
    private String ClassPosition;

    public String getClassName() {
        return ClassName;
    }

    public void setClassName(String className) {
        ClassName = className;
    }

    public String getClassName1() {
        return ClassName1;
    }

    public void setClassName1(String className1) {
        ClassName1 = className1;
    }

    public String getClassName2() {
        return ClassName2;
    }

    public void setClassName2(String className2) {
        ClassName2 = className2;
    }

    public String getClassName3() {
        return ClassName3;
    }

    public void setClassName3(String className3) {
        ClassName3 = className3;
    }

    public String getClassName4() {
        return ClassName4;
    }

    public void setClassName4(String className4) {
        ClassName4 = className4;
    }

    public String getClassName5() {
        return ClassName5;
    }

    public void setClassName5(String className5) {
        ClassName5 = className5;
    }

    public String getClassPosition() {
        return ClassPosition;
    }

    public void setClassPosition(String classPosition) {
        ClassPosition = classPosition;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
