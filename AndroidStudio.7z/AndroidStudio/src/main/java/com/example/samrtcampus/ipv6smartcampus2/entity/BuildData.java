package com.example.samrtcampus.ipv6smartcampus2.entity;

/**
 * Created by yangz on 2018/5/19.
 */

public class BuildData {
    private String BuildName;

    public BuildData(String buildName) {
        BuildName = buildName;
    }

    public String getBuildName() {
        return BuildName;
    }



    public void setBuildName(String buildName) {
        BuildName = buildName;

    }
}
