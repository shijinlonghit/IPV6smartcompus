package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.Search.ICallBack;
import com.example.samrtcampus.ipv6smartcampus2.Search.SearchView;
import com.example.samrtcampus.ipv6smartcampus2.Search.bCallBack;

/**
 * Created by yangz on 2018/5/19.
 */

public class SearchActivity extends AppCompatActivity{

    // 1. 初始化搜索框变量
    private SearchView searchView;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 2. 绑定视图
        setContentView(R.layout.activity_search);

        // 3. 绑定组件
        searchView = (SearchView) findViewById(R.id.search_view);

        // 4. 设置点击搜索按键后的操作
        // 参数=搜索框输入的内容
        searchView.setOnClickSearch(new ICallBack() {
            @Override
            public void SearchAciton(String string) {
                if (string.equals("1000001")|string.equals("1000002")|string.equals("1000003")|string.equals("1000004")|
                        string.equals("1000005")|string.equals("1000006")|string.equals("1000007")|string.equals("1000008")|
                        string.equals("1000009")|string.equals("1000010")|string.equals("1000011")|string.equals("1000012")|
                        string.equals("1000013")|string.equals("1000014")|string.equals("1000015")|string.equals("1000016")|
                        string.equals("1000017")|string.equals("1000018")){
                    Intent intent = new Intent(SearchActivity.this,FireDeviceActivity.class);
                    intent.putExtra("data",string);
                    startActivity(intent);

                }else {
                    Toast.makeText(SearchActivity.this,"您输入的设备不存在",Toast.LENGTH_SHORT).show();
                }
                //System.out.println("我收到了" + string);
            }
        });

        // 5. 设置点击返回按钮后的操作
        searchView.setOnClickBack(new bCallBack() {
            @Override
            public void BackAciton() {
                finish();
            }
        });
    }
}
