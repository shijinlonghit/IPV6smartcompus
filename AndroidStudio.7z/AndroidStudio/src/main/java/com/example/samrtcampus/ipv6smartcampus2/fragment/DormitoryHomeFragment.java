package com.example.samrtcampus.ipv6smartcampus2.fragment;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.DataClass.DormitoryInfo;
import com.example.samrtcampus.ipv6smartcampus2.R;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.UpdateListener;

/**
 * Created by yangz on 2018/5/2.
 */

public class DormitoryHomeFragment extends Fragment{

    //定义控件
    private TextView dormitoryTem;
    private TextView dormitoryElec;
    private TextView dormitoryNet;
    private Switch sw_dormitoryLight;
    //定义变量
    private String DormitoryTem;
    private String DormitoryElec;
    private String DormitoryNet;
    private String DormitoryLight;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dormitory_home,null);
        findView(view);
        return view;
    }

    private void findView(View view) {
        dormitoryTem = view.findViewById(R.id.dormitory_temp);
        dormitoryElec = view.findViewById(R.id.dormitory_elec);
        dormitoryNet = view.findViewById(R.id.dormitory_net);
        sw_dormitoryLight = view.findViewById(R.id.sw_light);
        sw_dormitoryLight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //切换相反
                sw_dormitoryLight.setSelected(!sw_dormitoryLight.isSelected());
                //更新Status状态
                if (sw_dormitoryLight.isChecked()){
                    DormitoryLight="1";
                }else if (!sw_dormitoryLight.isChecked()){
                    DormitoryLight="0";
                }
                DormitoryInfo dormitoryInfo = new DormitoryInfo();
                dormitoryInfo.setDormitoryLight(DormitoryLight);
                dormitoryInfo.update("aJ2k444N", new UpdateListener() {
                    @Override
                    public void done(BmobException e) {
                        //回调
                    }
                });
            }
        });

        BmobQuery<DormitoryInfo> query = new BmobQuery<DormitoryInfo>();
        query.getObject("aJ2k444N", new QueryListener<DormitoryInfo>() {
            @Override
            public void done(DormitoryInfo dormitoryInfo, BmobException e) {

                DormitoryTem = dormitoryInfo.getDormitoryTemperature();
                DormitoryElec = dormitoryInfo.getDormitoryElectricity();
                DormitoryNet = dormitoryInfo.getDormitoryNet();
                DormitoryLight = dormitoryInfo.getDormitoryNet();

                dormitoryTem.setText(DormitoryTem);
                dormitoryElec.setText(DormitoryElec);
                dormitoryNet.setText(DormitoryNet);

                if (TextUtils.equals(DormitoryLight,"1")){
                    sw_dormitoryLight.setChecked(true);
                }else if (TextUtils.equals(DormitoryLight,"0")){
                    sw_dormitoryLight.setChecked(false);
                }

            }
        });

    }


}
