package com.example.samrtcampus.ipv6smartcampus2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.entity.BuildData;

import java.util.List;

/**
 * Created by yangz on 2018/5/2.
 */

public class BuildingListAdapter extends BaseAdapter{

    private Context mContext;
    private LayoutInflater inflater;
    private List<BuildData>mList;
    private BuildData buildData;

    public BuildingListAdapter(Context mContext, List<BuildData>mList){
        this.mContext = mContext;
        this.mList = mList;
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder =null;
        if (convertView == null){
            viewHolder  = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_lv_building,null);
            viewHolder.tv_building=convertView.findViewById(R.id.tv_building);
            viewHolder.icon_arrow_build_list=convertView.findViewById(R.id.icon_arrow_build_list);
            convertView.setTag(viewHolder);

        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        buildData=mList.get(position);
        viewHolder.tv_building.setText(buildData.getBuildName());


        return convertView;
    }

    class ViewHolder{
        private TextView tv_building;
        private ImageView icon_arrow_build_list;

    }
}
