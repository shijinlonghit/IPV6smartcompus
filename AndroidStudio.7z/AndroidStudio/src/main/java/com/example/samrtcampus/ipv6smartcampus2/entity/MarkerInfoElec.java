package com.example.samrtcampus.ipv6smartcampus2.entity;

import com.example.samrtcampus.ipv6smartcampus2.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangz on 2018/5/3.
 */

public class MarkerInfoElec implements Serializable{
    private static final long serialVersionUID = 406409245964483150L;
    private double latitude;
    private double longitude;
    private int imgId;//正常应从url上获取一个Json，然后解析Json传入ui
    private int deviceNumber;
    private String deviceType;
    private String deviceLocation;
    private String time;

    public static List<MarkerInfoElec> infose= new ArrayList<MarkerInfoElec>();

    static {
        infose.add(new MarkerInfoElec(45.745464,126.638183, R.mipmap.a1000002,1000002,"电表","十五公寓","2018.04.02"));

    }

    public MarkerInfoElec(double latitude, double longitude, int imgId, int deviceNumber, String deviceType, String deviceLocation, String time) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.imgId = imgId;
        this.deviceNumber = deviceNumber;
        this.deviceType = deviceType;
        this.deviceLocation = deviceLocation;
        this.time = time;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getImgId() {
        return imgId;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

    public int getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(int deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceLocation() {
        return deviceLocation;
    }

    public void setDeviceLocation(String deviceLocation) {
        this.deviceLocation = deviceLocation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }



}
