package com.example.samrtcampus.ipv6smartcampus2;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.samrtcampus.ipv6smartcampus2.fragment.DormitoryDeviceFragment;
import com.example.samrtcampus.ipv6smartcampus2.fragment.DormitoryFrashFragment;
import com.example.samrtcampus.ipv6smartcampus2.fragment.DormitoryHomeFragment;

import java.util.ArrayList;
import java.util.List;

public class DormitoryActivity extends AppCompatActivity implements View.OnClickListener{


    //声明控件
    private LinearLayout mMyHome;
    private LinearLayout mDeviceRepair;
    private LinearLayout mWashSystem;
    //声明Fragment
    private List<Fragment>mFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dormitory);

        initData();
        initView();
    }

    private void initData() {
        mFragment = new ArrayList<>();
        mFragment.add(new DormitoryHomeFragment());//我的宿舍页
        mFragment.add(new DormitoryDeviceFragment());//设备维修页
        mFragment.add(new DormitoryFrashFragment());//洗衣系统页
    }


    private void initView() {
        mMyHome=findViewById(R.id.layout_dormitory_home);
        mDeviceRepair=findViewById(R.id.layout_dormitory_device);
        mWashSystem=findViewById(R.id.layout_dormitory_frash);

        mMyHome.setOnClickListener(this);
        mDeviceRepair.setOnClickListener(this);
        mWashSystem.setOnClickListener(this);

        this.getSupportFragmentManager().beginTransaction()
                .add(R.id.container_dormitory,mFragment.get(0))
                .add(R.id.container_dormitory,mFragment.get(1))
                .hide(mFragment.get(1))
                .add(R.id.container_dormitory,mFragment.get(2))
                .hide(mFragment.get(2))
                .commit();

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.layout_dormitory_home:
                this.getSupportFragmentManager().beginTransaction()
                        .show(mFragment.get(0))
                        .hide(mFragment.get(1))
                        .hide(mFragment.get(2))
                        .commit();
                break;
            case R.id.layout_dormitory_device:
                this.getSupportFragmentManager().beginTransaction()
                        .hide(mFragment.get(0))
                        .show(mFragment.get(1))
                        .hide(mFragment.get(2))
                        .commit();
                break;
            case R.id.layout_dormitory_frash:
                this.getSupportFragmentManager().beginTransaction()
                        .hide(mFragment.get(0))
                        .hide(mFragment.get(1))
                        .show(mFragment.get(2))
                        .commit();
                break;
        }

    }
}
