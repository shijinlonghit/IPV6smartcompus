package com.example.samrtcampus.ipv6smartcampus2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


import com.example.samrtcampus.ipv6smartcampus2.EnergyMapActivity;
import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.entity.BuildData;
import com.example.samrtcampus.ipv6smartcampus2.view.ExpandTabView;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewLeft;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewMiddle;
import com.example.samrtcampus.ipv6smartcampus2.view.ViewRight;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yangz on 2018/5/11.
 */

public class FireListActivity extends AppCompatActivity{

    private ExpandTabView expandTabView;
    private ArrayList<View> mViewArray = new ArrayList<View>();
    private ViewLeft viewLeft;
    private ViewMiddle viewMiddle;
    private ViewRight viewRight;
    private ImageView search;
    private Button map;


    private List<BuildData> buildList = new ArrayList<BuildData>();
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firelist);
        initView();
        initVaule();
        initListener();

    }
    private void initView() {

        expandTabView = (ExpandTabView) findViewById(R.id.expandtab_view);
        viewLeft = new ViewLeft(this);
        viewMiddle = new ViewMiddle(this);
        viewRight = new ViewRight(this);
        map = findViewById(R.id.energy_list_map);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FireListActivity.this,EnergyMapActivity.class));
                finish();
            }
        });
        search=findViewById(R.id.energy_list_search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FireListActivity.this,SearchActivity.class));
            }
        });

    }

    private void initVaule() {

//		mViewArray.add(viewLeft);
        mViewArray.add(viewMiddle);
//		mViewArray.add(viewRight);
        ArrayList<String> mTextArray = new ArrayList<String>();
//		mTextArray.add("项目1");
        mTextArray.add("校园建筑");
//		mTextArray.add("项目2");
        expandTabView.setValue(mTextArray, mViewArray);
//		expandTabView.setTitle(viewLeft.getShowText(), 0);
//		expandTabView.setTitle(viewMiddle.getShowText(), 1);
//		expandTabView.setTitle(viewRight.getShowText(), 2);

    }

    private void initListener() {

        viewLeft.setOnSelectListener(new ViewLeft.OnSelectListener() {

            @Override
            public void getValue(String showText) {
                onRefresh(viewLeft, showText);
            }
        });

        viewMiddle.setOnSelectListener(new ViewMiddle.OnSelectListener() {

            @Override
            public void getValue(String showText) {

                onRefresh(viewMiddle,showText);

            }
        });

        viewRight.setOnSelectListener(new ViewRight.OnSelectListener() {

            @Override
            public void getValue(String distance, String showText) {
                onRefresh(viewRight, showText);
            }
        });

    }

    private void onRefresh(View view, String showText) {

        expandTabView.onPressBack();
        int position = getPositon(view);
        if (position >= 0 && !expandTabView.getTitle(position).equals(showText)) {
            expandTabView.setTitle(showText, position);
        }
        Intent intent = new Intent(FireListActivity.this,FireDeviceActivity.class);
        intent.putExtra("data",showText);
        startActivity(intent);
        //Toast.makeText(MainActivity.this, showText, Toast.LENGTH_SHORT).show();

    }

    private int getPositon(View tView) {
        for (int i = 0; i < mViewArray.size(); i++) {
            if (mViewArray.get(i) == tView) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void onBackPressed() {

        if (!expandTabView.onPressBack()) {
            finish();
        }

    }





}
