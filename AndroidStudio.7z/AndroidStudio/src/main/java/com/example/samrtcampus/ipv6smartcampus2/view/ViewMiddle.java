package com.example.samrtcampus.ipv6smartcampus2.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.samrtcampus.ipv6smartcampus2.R;
import com.example.samrtcampus.ipv6smartcampus2.adapter.TextAdapter;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by yangz on 2018/5/20.
 */

public class ViewMiddle extends LinearLayout implements ViewBaseAction{
    private ListView regionListView;
    private ListView plateListView;
    private ArrayList<String> groups = new ArrayList<String>();
    private LinkedList<String> childrenItem = new LinkedList<String>();
    private SparseArray<LinkedList<String>> children = new SparseArray<LinkedList<String>>();
    private TextAdapter plateListViewAdapter;
    private TextAdapter earaListViewAdapter;
    private OnSelectListener mOnSelectListener;
    private int tEaraPosition = 0;
    private int tBlockPosition = 0;
    private String showString = "校园建筑";

    public ViewMiddle(Context context) {
        super(context);
        init(context);
    }

    public ViewMiddle(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public void updateShowText(String showArea, String showBlock) {
        if (showArea == null || showBlock == null) {
            return;
        }
        for (int i = 0; i < groups.size(); i++) {
            if (groups.get(i).equals(showArea)) {
                earaListViewAdapter.setSelectedPosition(i);
                childrenItem.clear();
                if (i < children.size()) {
                    childrenItem.addAll(children.get(i));
                }
                tEaraPosition = i;
                break;
            }
        }
        for (int j = 0; j < childrenItem.size(); j++) {
            if (childrenItem.get(j).replace("校园建筑", "").equals(showBlock.trim())) {
                plateListViewAdapter.setSelectedPosition(j);
                tBlockPosition = j;
                break;
            }
        }
        setDefaultSelect();
    }

    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.view_region, this, true);
        regionListView = (ListView) findViewById(R.id.listView);
        plateListView = (ListView) findViewById(R.id.listView2);
        setBackgroundDrawable(getResources().getDrawable(
                R.drawable.choosearea_bg_left));


        //向一级列表添加数据内容
        groups.add("学士楼");
        //tItem就是二级列表的数据内容，i代表第几行
        LinkedList<String> tItem = new LinkedList<String>();
        //二级列表内容
        tItem.add("1000004");
        tItem.add("1000005");
        tItem.add("1000009");
        //向二级列表添加内容方法
        children.put(0, tItem);
        groups.add("图书馆");
        //tItem就是二级列表的数据内容，i代表第几行
        LinkedList<String> tItem1 = new LinkedList<String>();
        //二级列表内容
        tItem1.add("1000006");
        tItem1.add("1000007");
        tItem1.add("1000008");
        //向二级列表添加内容方法
        children.put(1, tItem1);
        groups.add("电机楼");
        //tItem就是二级列表的数据内容，i代表第几行
        LinkedList<String> tItem2 = new LinkedList<String>();
        //二级列表内容
        tItem2.add("1000010");
        tItem2.add("1000011");
        tItem2.add("1000012");
        //向二级列表添加内容方法
        children.put(2, tItem2);
        groups.add("4公寓");
        //tItem就是二级列表的数据内容，i代表第几行
        LinkedList<String> tItem3 = new LinkedList<String>();
        //二级列表内容
        tItem3.add("1000002");
        tItem3.add("1000013");
        tItem3.add("1000014");
        //向二级列表添加内容方法
        children.put(3, tItem3);
        groups.add("13公寓");
        //tItem就是二级列表的数据内容，i代表第几行
        LinkedList<String> tItem4 = new LinkedList<String>();
        //二级列表内容
        tItem4.add("1000003");
        tItem4.add("1000017");
        tItem4.add("1000018");
        //向二级列表添加内容方法
        children.put(4, tItem4);
        groups.add("16公寓");
        LinkedList<String> tItem5 = new LinkedList<String>();
        //二级列表内容
        tItem5.add("1000001");
        tItem5.add("1000015");
        tItem5.add("1000016");
        //向二级列表添加内容方法
        children.put(5, tItem5);


        earaListViewAdapter = new TextAdapter(context, groups,
                R.drawable.choose_item_selected,
                R.drawable.choose_eara_item_selector);
        earaListViewAdapter.setTextSize(17);
        earaListViewAdapter.setSelectedPositionNoNotify(tEaraPosition);
        regionListView.setAdapter(earaListViewAdapter);
        earaListViewAdapter
                .setOnItemClickListener(new TextAdapter.OnItemClickListener() {

                    @Override
                    public void onItemClick(View view, int position) {
                        if (position < children.size()) {
                            childrenItem.clear();
                            childrenItem.addAll(children.get(position));
                            plateListViewAdapter.notifyDataSetChanged();
                        }
                    }
                });
        if (tEaraPosition < children.size())
            childrenItem.addAll(children.get(tEaraPosition));
        plateListViewAdapter = new TextAdapter(context, childrenItem,
                R.drawable.choose_item_right,
                R.drawable.choose_plate_item_selector);
        plateListViewAdapter.setTextSize(15);
        plateListViewAdapter.setSelectedPositionNoNotify(tBlockPosition);
        plateListView.setAdapter(plateListViewAdapter);
        plateListViewAdapter
                .setOnItemClickListener(new TextAdapter.OnItemClickListener() {

                    @Override
                    public void onItemClick(View view, final int position) {

                        showString = childrenItem.get(position);
                        if (mOnSelectListener != null) {

                            mOnSelectListener.getValue(showString);
                        }

                    }
                });
        if (tBlockPosition < childrenItem.size())
            showString = childrenItem.get(tBlockPosition);
        if (showString.contains("Building")) {
            showString = showString.replace("校园建筑", "");
        }
        setDefaultSelect();

    }

    public void setDefaultSelect() {
        regionListView.setSelection(tEaraPosition);
        plateListView.setSelection(tBlockPosition);
    }

    public String getShowText() {
        return showString;
    }

    public void setOnSelectListener(OnSelectListener onSelectListener) {
        mOnSelectListener = onSelectListener;
    }

    public interface OnSelectListener {
        public void getValue(String showText);
    }

    @Override
    public void hide() {
        // TODO Auto-generated method stub

    }

    @Override
    public void show() {
        // TODO Auto-generated method stub

    }
}
